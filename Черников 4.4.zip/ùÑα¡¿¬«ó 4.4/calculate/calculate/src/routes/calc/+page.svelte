<script>
    let firstNumber = 0;
    let secondNumber = 0;
    let result = 0;
    let operation = '';

    function calculate() {
        switch (operation) {
            case 'add':
                result = firstNumber + secondNumber;
                break;
            case 'subtract':
                result = firstNumber - secondNumber;
                break;
            case 'multiply':
                result = firstNumber * secondNumber;
                break;
            case 'divide':
                if (secondNumber !== 0) {
                    result = firstNumber / secondNumber;
                } else {
                    result = "Деление на 0";
                }
                break;
            default:
                result = "Недопустимая операция";
        }
    }
</script>

<style>
    .calculator {
        width: 300px;
        margin: 20px auto;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        text-align: center;
    }

    input {
        margin: 5px;
        padding: 5px;
        width: 80%;
    }

    button {
        margin: 5px;
        padding: 5px 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    p {
        font-size: 18px;
        margin-top: 10px;
    }
</style>

<div class="calculator">
    <h2>Калькулятор</h2>
    <input type="number" bind:value={firstNumber}>
    <select bind:value={operation}>
        <option value="add">+</option>
        <option value="subtract">-</option>
        <option value="multiply">*</option>
        <option value="divide">\</option>
    </select>
    <input type="number" bind:value={secondNumber}>
    <button on:click={calculate}>Посчитать</button>
    <p>Результат: {result}</p>
</div>